export const product = {}
